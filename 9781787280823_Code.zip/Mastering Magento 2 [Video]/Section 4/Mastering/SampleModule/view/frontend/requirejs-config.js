var config = {
    'map': {
        '*': {
            'mage/validation': 'Mastering_SampleModule/js/validation'
        }
    },
    config: {
        mixins: {
            'Mastering_SampleModule/js/validation': {
                'Mastering_SampleModule/js/validation-mixin': true
            }
        }
    }
};